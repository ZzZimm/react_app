import React from 'react';
import ListItem from './ListItem'

function App() {

  const listElem = [
    {
      title: "TITRE1",
      description: "DESCRIPTION1",
    },
    {
      title: "TITRE2",
      description: "DESCRIPTION2",
    },
    {
      title: "TITRE3",
      description: "DESCRIPTION3",
    },
  ];

  return (
    <>
    <header>
      <div id='headerContainer'>
        <div>To Do List<br /><br /></div>
        <div>
          <button id="addTask" onClick={() => {}}>+Add Task</button>
        </div>
      </div>
    </header>
    <table id="toDoList">
      <tbody>
        <tr>
            <th className="checkbox"></th>
            <th className="title">Title<button onClick={() => {}} className="button">sort</button></th>
            <th className="description">Description<button onClick={() => {}} className="button">sort</button></th>
            <th className="dueDate">Due date<button onClick={() => {}} className="button">sort</button></th>
            <th className="actionBox">Actions</th>
        </tr>
        {listElem.map((it) =>
        <ListItem key={it.title} title={it.title} description={it.description} />)}
      </tbody>
    </table>
    </>
  );
}

export default App;
