import React from 'react';
import iconModify from './icons/modify.png';
import iconValidate from './icons/validate.png';
import iconDelete from './icons/delete.png';

function ListItem(props) {
  const { title, description } = props;

  return (
    <tr id='task + maxIndex + '>
      <td className='checkbox'>
        <input type='checkbox' />
      </td>
      <td className='title'> {title}</td>
      <td className='description'> {description}</td>
      <td className='dueDate'><input type='date' /></td>
      <td>
        <img src={iconModify} alt='modify' onClick={() => {}} className='action'></img>
			  <img src={iconValidate} alt='validate' onClick={() => {}} className='action'></img>
			  <img src={iconDelete} alt='delete' onClick={() => {}} className='action'></img>
      </td>
    </tr>
  );
}

export default ListItem;
